#include<iostream>
using namespace std;
class Sports{
	private:
		string name;
		string typeOfSport;
	public:
			Sports(){
				name="Sarah";
				typeOfSport="Cricket";
			}
			Sports(string n, string ty){
				name=n;
				typeOfSport=ty;
			}
			void setName(string n){
				name=n;
			}
			string getName(){
				return name;
			}
			void setTypeOfSport(string ty){
				typeOfSport=ty;
			}
			string getTypeOfSport(){
				return typeOfSport;
			}
};

class Cricket:public Sports{
	private:
		string batmansName;
		string bowlerName;
	public:
		Cricket(){
			batmansName="Babar Azam";
			bowlerName="Naseem Shah";
			}
		Cricket(string bn, string wn){
			batmansName=bn;
			bowlerName=wn;
		}
		void setBatmansName(string bn){
				batmansName=bn;
			}
			string getBatmansName(){
				return batmansName;
			}
			void setBowlerName(string wn){
				 bowlerName=wn;
			}
			string getBowlerName(){
				return bowlerName;
			}
};

int main(){
	Cricket cricket;
	cricket.setBatmansName("Babar Azam");
	cricket.setBowlerName("Naseem Shah");
	
	cricket.setTypeOfSport("Football");
	
	cout<<"Cricket player:"<<cricket.getBatmansName()<<endl;
	cout<<"Bowler:"<<cricket.getBowlerName()<<endl;
	
	cout<<"Type of Sport:"<<cricket.getTypeOfSport()<<endl;
	
	return 0;
	}