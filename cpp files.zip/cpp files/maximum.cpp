#include<iostream>
using namespace std;

class Maximum{
	private:
	int num1;
	public:
		Maximum(int n) : num1(n) {}
		
		void setNum1(int n){
			num1=n;
		}
	friend int findMax(Maximum m, int num);	
};
int findMax(Maximum m, int num){
	return (m.num1 > num) ? m.num1 : num;
}
int main() {
	Maximum maxObj(10);
	int otherNum = 20;
    cout<<"Maximum Num is:"<<findMax(maxObj, otherNum)<<endl;
    return 0;
}
