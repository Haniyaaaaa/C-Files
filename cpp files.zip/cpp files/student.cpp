#include<iostream>
using namespace std;

class Student {
private:
    int rollNum;
public:
    Student(int rn) : rollNum(rn) {}

    int getRollNum() {
        return rollNum;
    }

    friend void displayRollNum(Student s);
};

void displayRollNum(Student s) {
    cout << "Roll num: " << s.getRollNum() << endl;
}

class Test : virtual public Student {
private:
    int score1, score2;
public:
    Test(int rn, int s1, int s2) : Student(rn), score1(s1), score2(s2) {}

    void setScore1(int s1) {
        score1 = s1;
    }
    
    int getScore1() {
        return score1;
    }
    
    void setScore2(int s2) {
        score2 = s2;
    }
    
    int getScore2() {
        return score2;
    }
    
    void display() {
        cout << "Score in subject one: " << score1 << endl;
        cout << "Score in subject two: " << score2 << endl;
    }
};

class Sports : virtual public Student {
private:
    int sportsScore;
public:
    Sports(int rn, int ss) : Student(rn), sportsScore(ss) {}

    void setSportsScore(int ss) {
        sportsScore = ss;
    }
    
    int getSportsScore() {
        return sportsScore;
    }
    
    void displayScore() {
        cout << "Score in Sports: " << sportsScore << endl;
    }
};

class Result : public Test, public Sports {
public:
    Result(int rn, int s1, int s2, int ss) : Student(rn), Test(rn, s1, s2), Sports(rn, ss) {}

    void displayResult() {
        cout << "Total result for roll num " << getRollNum() << " is: ";
        int totalResult = Test::getScore1() + Test::getScore2() + Sports::getSportsScore();
        cout << totalResult << endl;
    }
};

int main() {
    Result resultObj(101, 80, 85, 90);

    displayRollNum(resultObj);
    resultObj.Test::display();
    resultObj.Sports::displayScore();
    resultObj.displayResult();

    return 0;
}
