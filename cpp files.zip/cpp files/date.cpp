#include <iostream>
#include <iomanip>

using namespace std;

class Date {
private:
    int day;
    int month;
    int year;

public:
    Date(int d, int m, int y) : day(d), month(m), year(y) {}

    void setDay(int d) { day = d; }
    int getDay() const { return day; }

    void setMonth(int m) { month = m; }
    int getMonth() const { return month; }

    void setYear(int y) { year = y; }
    int getYear() const { return year; }

    void displayDate() const {
        cout << setfill('0') << setw(2) << day << "/"
            << setw(2) << month << "/" << year << endl;
    }
};

int main() {
    Date dates[] = {
        Date(10, 1, 2000),
        Date(20, 2, 2001),
        Date(30, 3, 2002),
        Date(15, 8, 2003),
        Date(5, 9, 2004)
    };

    for (const Date& date : dates) {
        date.displayDate();
    }

    return 0;
}