#include <iostream>
#include <string>
#include<algorithm>
using namespace std;

const int MAX_TEAMS = 10; // Maximum number of teams
const int MAX_PLAYERS = 100;

class Team {
private:
    string teamname;
    string players[11];
    string coachname;
    int wins;
    int losses;
    int draws;
    int noofplayers;

public:
    
    Team() : teamname(""), coachname(""), wins(0), losses(0), draws(0), noofplayers(0) {}

    Team(string name, string coach) : teamname(name), coachname(coach), wins(0), losses(0), draws(0), noofplayers(0) {}

    string getName() const {
        return teamname;
    }

    void addplayer(const string& player) {
        if (noofplayers < 11) {
            players[noofplayers] = player;
            cout << player << " is added to team" << endl;
            noofplayers++;
        } else {
            cout << "Team is full, so " << player << " is not added in the team" << endl;
        }
    }

    void removeplayer(const string& player) {
        for (int i = 0; i < noofplayers; i++) {
            if (player == players[i]) {
                players[i] = players[noofplayers - 1]; // Replace removed player with the last player
                noofplayers--; 
                cout << player << "is removed from the team" << endl;
                break;
            }
        }
    }

    void updatestats(int w, int l, int d) {
        wins = w;
        losses = l;
        draws = d;
        cout << "Team stats updated" << endl;
    }

    void displayinfo() const {
        cout << "Team name: " << teamname << endl;
        cout << "Coach name: " << coachname << endl;
        cout << "Players: " << endl;
        for (int i = 0; i < noofplayers; i++) {
            cout << players[i] << endl;
        }
        cout << "No of matches won: " << wins << ".\n No of matches team losses: " << losses << ".\nNo of draw matches: " << draws << endl;
    }
};

class Match {
private:
    string team1[11];
    string team2[11];
    int team1score = 0;
    int team2score = 0;
    string location;
    string date;

public:
    void schedulematch(const string& team1name, const string& team2name, const string& d, const string& l) {
        location = l;
        date = d;
        cout << "The match between " << team1name << " and " << team2name << " is held on " << d << " at " << l << endl;
    }

    void updatescore(int s1, int s2) {
        team1score = s1;
        team2score = s2;
    }

    void displaymatchdetails(const string& team1name, const string& team2name) const {
        cout << "Match scheduled on " << date << " at " << location << endl;
        if (team1score > team2score) {
            cout << team1name << " won the match" << endl;
        } else if (team1score < team2score) {
            cout << team2name << " won the match" << endl;
        } else {
            cout << "Tie Match" << endl;
        }
    }
};

class Player {
private:
    string name;
    string position;
    int goals;
    int assists;
    string teamAffiliation;

public:
    Player() : name(""), position(""), goals(0), assists(0), teamAffiliation("") {}

    Player(const string& n, const string& p, const string& t) : name(n), position(p), goals(0), assists(0), teamAffiliation(t) {}

    void updateStats(int g, int a) {
        goals += g;
        assists += a;
    }

    void setTeamAffiliation(const string& affiliation) {
        teamAffiliation = affiliation;
    }

    void transferToTeam(const string& newTeam) {
        teamAffiliation = newTeam;
    }

    void displayInfo() const {
        cout << "Name: " << name << "\nPosition: " << position << "\nGoals: " << goals << "\nAssists: " << assists << "\nTeam: " << teamAffiliation << endl;
    }

    bool operator==(const Player& other) const {
        return name == other.name;
    }

    string getName() const {
        return name;
    }

    void setName(const string& newName) {
        name = newName;
    }

    void setPosition(const string& newPosition) {
        position = newPosition;
    }
};

class Group {
private:
    string name;
    Team teams[MAX_TEAMS];
    int standings[MAX_TEAMS];
    int numTeams;

public:
    Group(const string& groupName) : name(groupName), numTeams(0) {}

    string getName() const {
        return name;
    }

    void addTeam(const Team& t) {
        if (numTeams < MAX_TEAMS) {
            teams[numTeams] = t;
            standings[numTeams] = 0;
            numTeams++;
        } else {
            cout << "Cannot add more teams. Group is full." << endl;
        }
    }

    void removeTeam(const Team& t) {
        for (int i = 0; i < numTeams; ++i) {
            if (teams[i].getName() == t.getName()) {
                for (int j = i; j < numTeams - 1; ++j) {
                    teams[j] = teams[j + 1];
                    standings[j] = standings[j + 1];
                }
                numTeams--;
                break;
            }
        }
    }

    void updateStandings(const Team& t, int pts) {
        for (int i = 0; i < numTeams; ++i) {
            if (teams[i].getName() == t.getName()) {
                standings[i] = pts;
                break;
            }
        }
    }

    void displayGroupInfo() const {
        cout << "Group Name: " << name << "\nTeams:" << endl;
        for (int i = 0; i < numTeams; ++i) {
            cout << teams[i].getName() << endl;
        }
        cout << "Standings:" << endl;
        for (int i = 0; i < numTeams; ++i) {
            cout << teams[i].getName() << "has" << standings[i] << "points." << endl;
        }
    }

    const Team* getTeams() const {
        return teams;
    }

    int getNumTeams() const {
        return numTeams;
    }
};

class League {
private:
    Group group;
    Match matches[MAX_TEAMS * (MAX_TEAMS - 1) / 2]; 

public:
    League(const string& name) : group(name) {}

    void addTeamToGroup(const Team& team) {
        group.addTeam(team);
    }

    void organizeMatches() {
        const Team* teams = group.getTeams();
        int numTeams = group.getNumTeams();
        int matchIndex = 0;
        for (int i = 0; i < numTeams; ++i) {
            for (int j = i + 1; j < numTeams; ++j) {
                matches[matchIndex].schedulematch(teams[i].getName(), teams[j].getName(), "2023-05-01", "Old Trafford");
                matches[matchIndex].updatescore(2, 1); 
                matchIndex++;
            }
        }
    }

    void updateLeagueTable() {
        const Team* teams = group.getTeams();
        int numTeams = group.getNumTeams();
        for (int i = 0; i < numTeams * (numTeams - 1) / 2; ++i) {
            matches[i].displaymatchdetails(teams[0].getName(), teams[1].getName()); 
        }
    }

    void simulateSeason() {
        for (int i = 0; i < 10; ++i) {
            organizeMatches();
            updateLeagueTable();
        }
    }

    const Team* getTeams() const {
        return group.getTeams();
    }
};

class ChampionLeague : public League {
public:
    ChampionLeague() : League("Champions League") {}

    void simulateChampionsLeagueMatch() {
        const Team* teams = getTeams();
        // Simulate match result
        int team1Score = 2;  
        int team2Score = 1;  
        cout << "Champions League Match Details:\n";
        cout << "Team 1: " << teams[0].getName() << " - Score: " << team1Score << "\n";
        cout << "Team 2: " << teams[1].getName() << " - Score: " << team2Score << "\n";
    }
};

class PremierLeague : public League {
public:
    PremierLeague() : League("Premier League") {}

    void simulatePremierLeagueMatch() {
        const Team* teams = getTeams();
        int team1Score = 3;  
        int team2Score = 2; 
        const_cast<Team&>(teams[0]).updatestats(1, 0, 0); 
        const_cast<Team&>(teams[1]).updatestats(0, 1, 0); 
        cout << "Premier League Match Details:\n";
        cout << "Team 1: " << teams[0].getName() << " - Score: " << team1Score << "\n";
        cout << "Team 2: " << teams[1].getName() << " - Score: " << team2Score << "\n";
    }
};

class Tournament {
	private:
		Player players[MAX_PLAYERS];
		int playerCount;
	public:
		Tournament() : playerCount(0) {} 
		
		void addPlayer(const Player& player) {
			if(playerCount < MAX_PLAYERS) {
				players[playerCount] = player;
				playerCount++;
				cout<<"Player is added"<<endl;
			} 
			else {
				cout<<"Team is full"<<endl;
			}
		}
		void displayPlayer() {
			for(int i=0; i<playerCount; i++){
				players[i].displayInfo();
				cout<<"---"<<endl;
			}
		}
		void updatePlayer(const string& name, const string& newPosition, const string& newTeamAffiliation) {
			for(int i=0; i<playerCount; i++) {
				if(players[i].getName()==name){
					players[i].setPosition(newPosition);
					players[i].setTeamAffiliation(newTeamAffiliation);
					cout<<"Player updated"<<endl;
					return;
				}
			}
			cout<<"Player not found"<<endl;
		}
		void delPlayer(const string& name) {
        for (int i = 0; i < playerCount; i++) {
            if (players[i].getName() == name) {
                for (int j = i; j < playerCount - 1; j++) {
                    players[j] = players[j + 1];
                }
                playerCount--;
                cout << "Player deleted" << endl;
                return;
            }
        }
        cout << "Player not found" << endl;
    }
};

void displayMenu() {
    cout << "\t\t\t\t--------------Enter your choice-----------------\n";
    cout << "\t\t\t\t1. Add Player\n";
    cout << "\t\t\t\t2. Display Players\n";
    cout << "\t\t\t\t3. Update Player\n";
    cout << "\t\t\t\t4. Delete Player\n";
    cout << "\t\t\t\t5. Simulate Premier League Match\n";
    cout << "\t\t\t\t6. Simulate Champions League Match\n";
    cout << "\t\t\t\t7. Exit\n";
}

int main() {
	     //login credentials 
	     char uname[100]= "admin";
		 char password[100] = "12345";
	     char u1[100], p1[100];
	     
	cout << "--------------------------------------------------------------------------------------";
    cout << "\n\t\t\t<<  Kindly Add Your Credentials >>";
    cout << "\n\t\t\t\tEnter Username:";
    cin >> u1;
	cout << "\n\t\t\t\tEnter Password:";
    cin >> p1;
    //check login credentials
     if (strcmp(uname, u1) == 0 && strcmp(password, p1) == 0) {
        cout << "\n\t\t\t\tWelcome! Login Successfully\n";
        system("COLOR A");
}
    
	
    Team t("Madrid", "Carlo Ancelotti");
    t.addplayer("Jude Bellhingam");
    t.addplayer("Ronaldo");
    t.addplayer("Benzema");
    t.removeplayer("Gavi");
    t.updatestats(3, 5, 1);
    t.displayinfo();

    Match m;
    m.schedulematch("FC", "Manchester", "7/3/2023", "Anfield");
    m.updatescore(4, 8);
    m.displaymatchdetails("FC", "Manchester");

    Player p;
    p.setName("NEYMAR");
    p.setPosition("Forward");
    p.updateStats(5, 3);
    p.transferToTeam("Team B");
    p.displayInfo();

    Team team1("Team 1", "Coach 1");
    Team team2("Team 2", "Coach 2");
    Team team3("Team 3", "Coach 3");

    Group g("Group A");
    g.addTeam(team1);
    g.addTeam(team2);
    g.addTeam(team3);
    g.updateStandings(team1, 3);
    g.updateStandings(team2, 1);
    g.updateStandings(team3, 2);
    g.removeTeam(team2);
    g.displayGroupInfo();

    PremierLeague premierLeague;
    premierLeague.simulateSeason();

    ChampionLeague championLeague;
    championLeague.simulateSeason();
    
    Tournament tournament;
    int choice;

    do {
        system("cls");
        displayMenu();
        cin >> choice;

        switch (choice) {
            case 1:
                {
                    string name, position, teamAffiliation;
                    cout << "Enter player name: ";
                    cin.ignore();
                    getline(cin, name);
                    cout << "Enter position: ";
                    cin >> position;
                    cout << "Enter team affiliation: ";
                    cin >> teamAffiliation;
                    Player player(name, position, teamAffiliation);
                    tournament.addPlayer(player);
                    break;
                }
            case 2:
                tournament.displayPlayer();
                break;
            case 3:
                {
                    string name, newPosition, newTeamAffiliation;
                    cout << "Enter player name to update: ";
                    cin.ignore();
                    getline(cin, name);
                    cout << "Enter new position: ";
                    cin >> newPosition;
                    cout << "Enter new team affiliation: ";
                    cin >> newTeamAffiliation;
                    tournament.updatePlayer(name, newPosition, newTeamAffiliation);
                    break;
                }
            case 4:
                {
                    string name;
                    cout << "Enter player name to delete: ";
                    cin.ignore();
                    getline(cin, name);
                    tournament.delPlayer(name);
                    break;
                }
            case 5:
                cout << "Simulating Premier League Match..." << endl;
                premierLeague.simulateSeason();
                break;
            case 6:
                cout << "Simulating Champions League Match..." << endl;
                championLeague.simulateSeason();
                break;
            case 7:
                char confirm;
                cout << "you want to exit?(y/n)..." << endl;
                
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                cin.clear();
                cin.ignore();
        }
    } while (true);

    return 0;
}
