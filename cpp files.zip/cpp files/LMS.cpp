#include <iostream>
#include <string>
using namespace std;

const int MAX_BOOKS = 100;
const int MAX_MEMBERS = 100;
const int MAX_STAFF = 100;

class Book {
private:
    string title;
    string author;
    string isbn;
    bool isAvailable;

public:
    Book(string title, string author, string isbn) 
        : title(title), author(author), isbn(isbn), isAvailable(true) {}

    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    string getISBN() const { return isbn; }
    bool getStatus() const { return isAvailable; }

    void borrow() {
        if (isAvailable) {
            isAvailable = false;
            cout << "Book '" << title << "' borrowed." << endl;
        } else {
            cout << "Book '" << title << "' is currently unavailable." << endl;
        }
    }

    void returnBook() {
        isAvailable = true;
        cout << "Book '" << title << "' returned." << endl;
    }
};

// Abstract base class: Person
//Inheritance:- The Person class is an abstract base class that defines the common properties and behaviors for Member and Staff classes.
class Person {
protected:
    string name;
    int id;
public:
    Person(string name, int id) : name(name), id(id) {}
    virtual void login() = 0; // Pure virtual function
    virtual void logout() = 0; // Pure virtual function
    int getId() const { return id; } // Public method to access id
    virtual ~Person() = default;
};

// Derived class: Member
//Inheritance:- The Member and Staff classes inherit from the Person class, inheriting the name, id, login(), and logout() members.
//Association:- The Member class has an association with the Book class, allowing members to borrow and return books.
class Member : public Person {
private:
    Book* borrowedBooks[MAX_BOOKS];    //Aggreation relation with book class
    int borrowedCount;

public:
    Member(string name, int id) : Person(name, id), borrowedCount(0) {
        for(int i = 0; i < MAX_BOOKS; ++i) {
            borrowedBooks[i] = nullptr;
        }
    }

    virtual void login() {
        cout << "Member " << name << " logged in." << endl;
    }

     virtual void logout() {
        cout << "Member " << name << " logged out." << endl;
    }

    void borrowBook(Book* book) {
        if (borrowedCount < MAX_BOOKS && book->getStatus()) {
            book->borrow();
            borrowedBooks[borrowedCount++] = book;
        } else {
            cout << "Cannot borrow the book '" << book->getTitle() << "' as it is already borrowed or limit exceeded." << endl;
        }
    }

    void returnBook(Book* book) {
        for (int i = 0; i < borrowedCount; ++i) {
            if (borrowedBooks[i] == book) {
                book->returnBook();
                borrowedBooks[i] = borrowedBooks[--borrowedCount];
                borrowedBooks[borrowedCount] = nullptr;
                return;
            }
        }
        cout << "This book was not borrowed by the member." << endl;
    }

    void showBorrowedBooks() {
        cout << "Books borrowed by " << name << ":" << endl;
        for (int i = 0; i < borrowedCount; ++i) {
            if (borrowedBooks[i] != nullptr) {
                cout << borrowedBooks[i]->getTitle() << endl;
            }
        }
    }
};

// Derived class: Staff
class Staff : public Person {
public:
    Staff(string name, int id) : Person(name, id) {}

   virtual void login()  {
        cout << "Staff " << name << " logged in." << endl;
    }

    virtual void logout()  {
        cout << "Staff " << name << " logged out." << endl;
    }

    void manageInventory() {
        cout << "Staff " << name << " is managing the inventory." << endl;
    }
};


//Association:- The Library class has associations with the Book and Member classes, allowing it to find and interact with these objects.
class Library {
private:
    Book* books[MAX_BOOKS];         //Aggregation relation with book
    Member* members[MAX_MEMBERS];   //Aggregation relation with member
    Staff* staff[MAX_STAFF];        //Aggregation relation with staff
    int bookCount;
    int memberCount;
    int staffCount;

public:
    Library() : bookCount(0), memberCount(0), staffCount(0) {
        for (int i = 0; i < MAX_BOOKS; ++i) {
            books[i] = nullptr;
        }
        for (int i = 0; i < MAX_MEMBERS; ++i) {
            members[i] = nullptr;
        }
        for (int i = 0; i < MAX_STAFF; ++i) {
            staff[i] = nullptr;
        }
    }

    ~Library() {
        for (int i = 0; i < bookCount; ++i) {
            delete books[i];
        }
        for (int i = 0; i < memberCount; ++i) {
            delete members[i];
        }
        for (int i = 0; i < staffCount; ++i) {
            delete staff[i];
        }
    }

    void addBook(Book* book) {
        if (bookCount < MAX_BOOKS) {
            books[bookCount++] = book;
        } else {
            cout << "Cannot add more books. Limit reached." << endl;
        }
    }

    void addMember(Member* member) {
        if (memberCount < MAX_MEMBERS) {
            members[memberCount++] = member;
        } else {
            cout << "Cannot add more members. Limit reached." << endl;
        }
    }

    void addStaff(Staff* staffMember) {
        if (staffCount < MAX_STAFF) {
            staff[staffCount++] = staffMember;
        } else {
            cout << "Cannot add more staff. Limit reached." << endl;
        }
    }

    void showBooks() {
        cout << "Library Books:" << endl;
        for (int i = 0; i < bookCount; ++i) {
            cout << books[i]->getTitle() << " by " << books[i]->getAuthor() << " (ISBN: " << books[i]->getISBN() << ")" << endl;
        }
    }

    Member* findMember(int id) {
        for (int i = 0; i < memberCount; ++i) {
            if (members[i]->getId() == id) {
                return members[i];
            }
        }
        return nullptr;
    }

    Book* findBook(string isbn) {
        for (int i = 0; i < bookCount; ++i) {
            if (books[i]->getISBN() == isbn) {
                return books[i];
            }
        }
        return nullptr;
    }
};

int main() {
    Library library;

    library.addBook(new Book("The Great Gatsby", "F. Scott Fitzgerald", "123456789"));
    library.addBook(new Book("1984", "George Orwell", "987654321"));

    library.addMember(new Member("Alice", 1));
    library.addMember(new Member("Bob", 2));

    library.addStaff(new Staff("Charlie", 101));

    library.showBooks();

    Member* member = library.findMember(1);
    Book* book = library.findBook("123456789");

    if (member && book) {
        member->login();
        member->borrowBook(book);
        member->showBorrowedBooks();
        member->logout();
    }

    // Return the book
    if (member && book) {
        member->login();
        member->returnBook(book);
        member->showBorrowedBooks();
        member->logout();
    }

    return 0;
}
