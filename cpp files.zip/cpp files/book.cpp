#include<iostream>
#include<string>
using namespace std;

class Book {
private:
    string title;
    string author;
    int publicationYear;
    double price;

public:
    // Setters
    void setTitle(const string& t) {
        title = t;
    }

    void setAuthor(const string& a) {
        author = a;
    }

    void setPublicationYear(int year) {
        publicationYear = year;
    }

    void setPrice(double p) {
        price = p;
    }

    // Getters
    string getTitle() const {
        return title;
    }

    string getAuthor() const {
        return author;
    }

    int getPublicationYear() const {
        return publicationYear;
    }

    double getPrice() const {
        return price;
    }

    // Calculate discounted price
    double getDiscountedPrice() const {
        return price * 0.9; // 10% discount
    }
};

int main() {
    Book book;
    book.setTitle("The Kite Runner");
    book.setAuthor("Khaled Hosseini");
    book.setPublicationYear(2003);
    book.setPrice(19.99);

    cout << "Book Details:" << endl;
    cout << "Title: " << book.getTitle() << endl;
    cout << "Author: " << book.getAuthor() << endl;
    cout << "Publication Year: " << book.getPublicationYear() << endl;
    cout << "Price: $" << book.getPrice() << endl;
    cout << "Discounted Price: $" << book.getDiscountedPrice() << endl;

    return 0;
}