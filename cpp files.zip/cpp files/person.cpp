#include<iostream>
using namespace std;

class Person{
	int age;
	string name;
	public:
		Person() {
		age=20;
		name="hania";
		}
		Person(int a, string n){
			age=a;
			name=n;
		}
		int getAge(){
			return age;
		}
		string getName(){
			return name;
		}
		
		void display(){
			cout<<"Age:"<<age<<endl;
			cout<<"Name:"<<name<<endl;
		}
};

int main(){
			Person p;
			p.display();
			
			return 0;
		}