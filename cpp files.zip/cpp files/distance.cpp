#include <iostream>

using namespace std;

class Distance {
private:
    int feet;
    int inches;

public:
    // Default constructor
    Distance() {
        feet = 0;
        inches = 0;
    }

    // Parameterized constructor
    Distance(int ft, int in) {
        feet = ft;
        inches = in;
    }

    // Setter functions
    void setFeet(int ft) {
        feet = ft;
    }

    void setInches(int in) {
        inches = in;
    }

    // Getter functions
    int getFeet() const {
        return feet;
    }

    int getInches() const {
        return inches;
    }

    // Display function
    void display() const {
        int totalInches = (feet * 12) + inches;
        int displayFeet = totalInches / 12;
        int displayInches = totalInches % 12;

        cout << "Feet: " << displayFeet << endl;
        cout << "Inches: " << displayInches << endl;
    }
};

int main() {
    int feet, inches;

    cout << "Enter the distance in feet: ";
    cin >> feet;

    cout << "Enter the distance in inches: ";
    cin >> inches;

    Distance distance(feet, inches);

    cout << "Output: " << endl;
    distance.display();

    return 0;
}