#include<iostream>
using namespace std;

class bankAccount{
	private:
		double balance;
	public:
		bankAccount(double bal) : balance(bal){}
		
		friend void compareBalance(bankAccount& acc1, bankAccount& acc2);
};

void compareBalance(bankAccount& acc1, bankAccount& acc2){
	if(acc1.balance > acc2.balance) {
		cout<<"Account 1 has higher balance";
	}
	else if(acc1.balance < acc2.balance) {
		cout<<"Account 2 has lower balance";
	}
	else {
		cout<<"both have same balance";
	}
}
int main() {
	bankAccount acc1(50000.0);
	bankAccount acc2(34000.0);
	
	compareBalance(acc1 , acc2);
	return 0;
}