#include<iostream>
#include<fstream>
using namespace std;

class BankAccount {
	private:
		int accNum;
		string accHolderName;
		double balance;
	public:
		//default constructor 
		accNum = 0;
		accHolderName = "";
		balance = 0.0;
	    //parameterized constructor
		BankAccount(int a, string hn, double b) {
			accNum = a;
			accHolderName = hn;
			balance = b;
		}	
		void setAccNum(int a){
			accNum = a;
		}
		int getAccNum() {
			return accNum;
		}
		void setAccHolderName(string hn) {
			return accHolderName;
		}
		string getAccHolderName(){
			return accHolderName;
		}
		void setBalance(double b){
			return balance;
		}
		//copy constructor
		BankAccount(const BankAccount& other) {
			accNum = other.accNum;
			accHolderName = other.accHolderName;
			balance = other.balance;
		}
		void deposit(double amount){
			balance += amount
		}
		void withdraw(double amount){
			balance -= amount;
		}
		void display(){
			cout<<"Account Number:"<<accNum<<endl;
			cout<<"Account Holder Name:"<<accHolderName<<endl;
			cout<<"Balance:"<<balance<<endl;
		}
		//operator overloading
		BankAccount operator+(const BankAccount& other){
			BankAccount result;
			result.accNum = this->accNum;
			result.accHolderName = this->accHolderName;
			result.balance = this->balance + other.balance;
			return result;
		}
		//overloading assignment operator
		BanlAccount& operator+(BankAccount& other) {
			if(this != &other){
				accNum = other.accNum;
				accHolderName = other.accHolderName;
				balance = other.balance;
			}
			return *this;
		}
		virtual double calInterest(){
			return 0.0
		}	
};

class SavingsAccount : public BankAccount {
	private:
		double interestRate;
		double minBalance;
	public:
		SavingsAccount(int a, string hn, double b, double ir, double mb) : BankAccount(a, hn, b){
			interestRate = ir;
			minBalance = mb;
		}
		void setInterestRate(double ir){
			interestRate = ir;
		}
		double getInterestRate() {
			return interestRate;
		}
		void setMinBalance(double minBalance){
			minBalance = mb;
		}
		double getMinBalance() {
			return minBalance;
		}
		//overriding
		double calInterest() {
			return balance * interestRate;
		}
		bool balanceIsLow() {
			return balance < minBalance;
		}
};

class CheckingAccount : public BankAccount {
	private:
		double overdraftLimit;
	public:
		CheckingAccount(int a, string hn, double b, double odLim) : BankAccount(a, hn, b) {
			overdraftLimit = odLim;
		}
		void setOverDraftLimit(double odLim) {
			overdraftLimt = odLim;
		}
		double getOverDraftLimit(){
			return overdraftLimit;
		}
		bool isWithdrawalAllowed(double amount){
			return (balance - amount >= -overdraftLimit);
		}
};

int main() {
	SavingsAccount savingsAccount(234567, "Hassan", 5000.0, 0.05, 1000.0);
	savingsAccount.deposit(2000.0);
	savingsAccount.withdraw(1000.0);
	savingsAccount.display();
	
	double earnedInterest = savingsAccount.calInterest();
	cout<<"Interest Earned:"<<earnedInterest<<endl;
	
	bool isBalanceLow = savingsAccount.balanceIsLow();
	 if (isBalanceLow) {
	 	cout<<"Balance in thie saving account is low"<<endl;
	 } else {
	 	cout<<"Balance in the savings account is sufficient"<<endl;
	 }
	 
	 CheckingAccount checkingAccount(1234, "Ali", 1000.0,, 500.0);
	 checkingAccount.deposit(2000.0);
	 checkingAccount.withdraw(2500.0);
	 checkingAccount.display();
	 
	 double withdrawalAmount = 3000.0;
	 bool isWithdrawalAllowed = checkingAccount.isWithdrawalAllowed(withdrawalAmount);
	 if(isWithdrawalAmount) {
	 	cout<<"Withdrawal of"<<withdrawalAmount<<"is allowed from the account"<<endl;
	 	} 
	else if{
		cout<<"Withdrawal of"<<withdrawalAmount<<"is not allowed from the account"<<endl;
	}
	return 0;
}
