#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int countWord(string& filename) {
	ifstream file(filename);
	if(!file.is_open()) {
		cout<<"failed to open!"<<endl;
		return 0;
	}
string word;
int count = 0;
while(file >> word) {
	count++;
}
file.close();
return count;
}

int main() {
	string filename = "text_file.text";
	int wordCount = countWord(filename);
	
	cout<<"Total word in file:" <<wordCount <<endl;
	
	return 0;
}