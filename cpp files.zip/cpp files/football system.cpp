#include<iostream>
#include<string>
using namespace std;


class Team{
    private:
string teamname;
string players[11];
string coachname;
int wins;
int losses;
int draws;
int noofplayers;
public:
Team(string name,string coach){
    teamname=name;
    coachname=coach;
    wins=0;
    losses=0;
    draws=0;
    noofplayers=0;
}
void addplayer(string player){
if(noofplayers<11){
players[noofplayers]=player;
cout<<player<<" is added to team"<<endl;
noofplayers++;
}
else{
    cout<<"Team is full,so "<<player<<" is not added to team"<<endl;
}
}
void removeplayer(string player){
for(int i=0;i<noofplayers;i++){
    if(player==players[i]){
          players[i]=" ";
    }
}
cout<<player<<" removed from team"<<endl;
}
void updatestats(int w,int l,int d){
    wins=w;
    losses=l;
    draws=d;
    cout<<"Team stats updated"<<endl;
}
void displayinfo(){
    cout<<"Team name: "<<teamname<<endl;
    cout<<"Coach name: "<<coachname<<endl;
    cout<<"Players: "<<endl;
    for(int i=0;i<noofplayers;i++){
        cout<<players[i]<<endl;
    }
    cout<<"No of matches won: "<<wins<<". No of matches team losses: "<<losses<<". No of draw matches: "<< draws<<endl;
}
};


class Match{
    string team1[11]={"David","Dean","Tom","Harry","Victor","Raphaël","Eric","Luke","Alex","Brandon","Tyrell"};
    string team2[11]={"Kingsley","Robert","Dayot ","Serge","Thomas","Alphonso","Leon","Joshua","","Manuel","Scott"};
    int team1score=0;
    int team2score=0;
    string location;
    string date;
    public:
    void schedulematch(string team1name,string team2name,string d,string l){
        cout<<"The match between "<<team1name<<" and "<<team2name<<" is held on "<<d<<" at "<<l<<endl;
    }
    void updatescore(int s1,int s2){
        team1score=s1;
        team2score=s2;
    }
    void displaymatchdetails(int s1,string team1,int s2,string team2){
       if(s1>s2){
        cout<<team1<<" won the match"<<endl; 
       } 
       else if(s1<s2){
        cout<<team2<<" won the match"<<endl; 
       } 
    }
};


class Player {
private:
    string name;
    string position;
    int goals;
    int assists;
    string teamAffiliation;

public:
    Player(string n, string p, string t) : name(n), position(p), goals(0), assists(0), teamAffiliation(t) {}

    void updateStats(int g, int a) {
        goals += g;
        assists += a;
    }

    void transferToTeam(string newTeam) {
        teamAffiliation = newTeam;
    }

    void displayInfo() {
        cout << "Name: " << name << "\nPosition: " << position << "\nGoals: " << goals << "\nAssists: " << assists << "\nTeam: " << teamAffiliation << endl;
    }

    // Overloading the equality operator
    bool operator==(const Player& other) {
        return name == other.name;
    }

    string getName() {
        return name;
    }

    void setPosition(string newPosition) {
        position = newPosition;
    }
};

class Group {
private:
    string name;
    Team** teams;
    int teamCount;
    int* standings;

public:
    Group(const string& groupName) : name(groupName), teams(nullptr), standings(nullptr), teamCount(0) {}

    ~Group() {
        delete[] teams;
        delete[] standings;
    }

    string getName() const{
    	return name;
	}

    void addTeam(Team* t) {
        Team** tempTeams = new Team*[teamCount + 1];
        for (int i = 0; i < teamCount; i++) {
            tempTeams[i] = teams[i];
        }
        tempTeams[teamCount] = t;
        delete[] teams;
        teams = tempTeams;
        teamCount++;

        int* tempStandings = new int[teamCount];
        for (int i = 0; i < teamCount - 1; i++) {
            tempStandings[i] = standings[i];
        }
        tempStandings[teamCount - 1] = 0;
        delete[] standings;
        standings = tempStandings;
    }

    void removeTeam(Team* t) {
        int index = -1;
        for (int i = 0; i < teamCount; i++) {
            if (teams[i] == t) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            Team** tempTeams = new Team*[teamCount - 1];
            for (int i = 0, j = 0; i < teamCount; i++) {
                if (i != index) {
                    tempTeams[j] = teams[i];
                    j++;
                }
            }
            delete[] teams;
            teams = tempTeams;
            teamCount--;

            int* tempStandings = new int[teamCount];
            for (int i = 0, j = 0; i < teamCount + 1; i++) {
                if (i != index) {
                    tempStandings[j] = standings[i];
                    j++;
                }
            }
            delete[] standings;
            standings = tempStandings;
        }
    }

    void updateStandings(Team* t, int pts) {
        for (int i = 0; i < teamCount; i++) {
            if (teams[i] == t) {
                standings[i]= pts;
                break;
            }
        }
    }

    void displayGroupInfo() {
        cout << "Group Name: " << name << "\nTeams:" << endl;
        for (int i = 0; i < teamCount; i++) {
            cout << (*teams[i]).getName() << endl;
        }
        cout << "Standings:" << endl;
        for (int i = 0; i < teamCount; i++) {
            cout << teams[i]->getName() << "_" << standings[i] << "pts" << endl;
        }
    }
};

int main(){
    Team t("Madrid","FC Barca");
    t.addplayer("Jude Bellhingam");
    t.addplayer("Ronaldo");
    t.addplayer("Gavi");
    t.removeplayer("Benzema");
    t.updatestats(3,5,1);
    t.displayinfo();
    
    Match m;
    m.schedulematch(" FC "," Manchester","7/3/2023","Anfield");
    m.updatescore(4,8);
    m.displaymatchdetails(4,"FC",8,"Manchester");
    
    Player p;
    p.setName("NEYMAR");
    p.setPosition("Forward");
    p.updateStats(5,3);
    p.transferToTeam("Team B");
    p.displayInfo();
    
    Team* team1 = new Team{"Team 1"};
    Team* team2 = new Team{"Team 2"};
    Team* team3 = new Team{"Team 3"};
    
    Group g;
    g.addTeam(team1);
    g.addTeam(team2);
    g.addTeam(team3);
    g.updateStandings(team1, 3);
    g.updateStandings(team2, 1);
    g.updateStandings(team3, 2);
    g.removeTeam(team2);
    g.displayGroupInfo();
    
    //clean memory
    delete team1;
    delete team3;
}