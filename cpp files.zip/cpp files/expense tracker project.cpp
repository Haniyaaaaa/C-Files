#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

class Expense {
protected:
    string date;
    double amount;
    string category;
    string description;

public:
    Expense() {}

    Expense(string d, double a, string c, string desc) : date(d), amount(a), category(c), description(desc) {}

     void display() {
        cout << "Date: " << date << endl;
        cout << "Amount: $" << fixed << setprecision(2) << amount << endl;
        cout << "Category: " << category << endl;
        cout << "Description: " << description << endl;
    }

     double getAmount() {
        return amount;
    }

    string getCategory() {
        return category;
    }
};

class DetailedExpense : public Expense {
private:
    string location;

public:
    DetailedExpense(string d, double a, string c, string desc, string loc) : Expense(d, a, c, desc), location(loc) {}

    void display() override {
        Expense::display();
        cout << "Location: " << location << endl;
    }
};

class ExpenseTracker {
private:
    Expense* expenses[100];
    int numExpenses;

public:
    ExpenseTracker() : numExpenses(0) {}

    void addExpense(Expense* expense) {
        if (numExpenses < 100) {
            expenses[numExpenses] = expense;
            numExpenses++;
            cout << "Expense added successfully!" << endl;
        } else {
            cout << "Maximum number of expenses reached!" << endl;
        }
    }

    void displayExpenses() {
        cout << "----- Expenses -----" << endl;
        for (int i = 0; i < numExpenses; i++) {
            expenses[i]->display();
            cout << endl;
        }
        cout << "---------------------" << endl;
    }
};

int main() {
    ExpenseTracker expenseTracker;

    Expense expense1("2022-01-05", 50.0, "Food", "Lunch at a restaurant");
    DetailedExpense expense2("2022-01-10", 30.0, "Transportation", "Bus fare", "Bus station");
    Expense expense3("2022-01-15", 20.0, "Food", "Dinner at a cafe");

    expenseTracker.addExpense(&expense1);
    expenseTracker.addExpense(&expense2);
    expenseTracker.addExpense(&expense3);

    expenseTracker.displayExpenses();

    return 0;
}
