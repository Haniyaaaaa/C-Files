#include<iostream>
using namespace std;

class Worker{
	private:
		string name;
		int workingHours;
	public:
		Worker(string n, int wh) : name(n), workingHours(wh) {}
	
	void setName(string n){
		name=n;
	}
	string getName() {
		return name;
	}
	void intWorkingHours(int wh){
		workingHours=wh;
	}
	int getWorkingHours(){
		return workingHours;
	}
	void display() {
		cout<<"Name:"<<name<<endl;
		cout<<"Working hours:"<<workingHours<<endl;
	}
};

class Employee : public Worker {
	private:
		string deptName;
		double salary;
	public:
		Employee(string n, int wh, string dn, double s) : Worker(n, wh), deptName(dn), salary(s) {}
		
		void setDeptName(string dn){
			deptName=dn;
		}
		string getDeptName() {
			return deptName;
		}
		void setSalary(double s){
			salary=s;
		}
		double getSalary(){
			return salary;
		}
		void displayInfo() {
			cout<<"Department Name:"<<deptName<<endl;
			cout<<"Salary:"<<salary<<endl;
	}
};

class Manager : public Worker {
	private: 
	   int managedEmployee;
	   int numOfProject;
	public:
		Manager(string n, int wh, int me, int p) : Worker(n, wh), managedEmployee(me), numOfProject(p) {}
		
		void setManagedEmployee(int me) {
			managedEmployee=me;
		}
		int getManagedEmployee() {
			return managedEmployee;
		}
		void setNumOfProject(int p){
			numOfProject=p;
		}
		int getNumOfProject() {
			return numOfProject;
		}
	void displayDetails() {
		cout<<"Mananged Employee:"<<managedEmployee<<endl;
		cout<<"Number of projects:"<<numOfProject<<endl;
	}
};

class Project{
	private:
		string name;
		int progress;
	public:
		Project(string n, int p) : name(n), progress(p) {}
		
		void setName(string n) {
			name=n;
		}
		string getName() {
			return name;
		}
		void setProgress(int p){
			progress=p;
		}
};

int main() {
	Employee* emp= new Employee("Ayesha", 38, "SE", 50000);
	Manager* mgr= new Manager("Habiba", 43, 5, 3);
	
	emp->display();
	emp->displayInfo();
	
	mgr->display();
	mgr->displayDetails();
	
	delete emp;
	delete mgr;
	
	return 0;
}






