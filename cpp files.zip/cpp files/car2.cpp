#include<iostream>
using namespace std;

class Car {
	protected:
      string brand;
      string model;
      int year;
      double price;
    public:
    	Car(string b, string m, int y, double p) : brand(b), model(m), year(y), price(p) {}
    	
    void display() {
    	cout<<"Brand:"<<brand<<endl;
    	cout<<"Model:"<<model<<endl;
    	cout<<"Year:"<<year<<endl;
    	cout<<"Price: $"<<price<<endl;
	}
};
	void displayDetails(Car* car){
		car->display();
	}
	
	int main() {
		Car c("Jaguar", "Ftyper", 2024, 1000000.0);
		
		displayDetails(&c);
		return 0;
	}