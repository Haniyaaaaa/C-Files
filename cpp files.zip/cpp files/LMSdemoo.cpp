#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// Class: Book
class Book {
private:
    string title;
    string author;
    string isbn;
    bool isAvailable;

public:
    Book(string title, string author, string isbn) 
        : title(title), author(author), isbn(isbn), isAvailable(true) {}

    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    string getISBN() const { return isbn; }
    bool getStatus() const { return isAvailable; }

    void borrow() {
        if (isAvailable) {
            isAvailable = false;
            cout << "Book '" << title << "' borrowed." << endl;
        } else {
            cout << "Book '" << title << "' is currently unavailable." << endl;
        }
    }

    void returnBook() {
        isAvailable = true;
        cout << "Book '" << title << "' returned." << endl;
    }
};

// Abstract base class: Person
class Person {
protected:
    string name;
    int id;
public:
    Person(string name, int id) : name(name), id(id) {}
    virtual void login() = 0; // Pure virtual function
    virtual void logout() = 0; // Pure virtual function
    virtual ~Person() = default;
};

// Derived class: Member
class Member : public Person {
private:
    vector<Book*> borrowedBooks;
public:
    Member(string name, int id) : Person(name, id) {}

    void login() override {
        cout << "Member " << name << " logged in." << endl;
    }

    void logout() override {
        cout << "Member " << name << " logged out." << endl;
    }

    void borrowBook(Book* book) {
        if (book->getStatus()) {
            book->borrow();
            borrowedBooks.push_back(book);
        } else {
            cout << "Cannot borrow the book '" << book->getTitle() << "' as it is already borrowed." << endl;
        }
    }

    void returnBook(Book* book) {
        auto it = find(borrowedBooks.begin(), borrowedBooks.end(), book);
        if (it != borrowedBooks.end()) {
            book->returnBook();
            borrowedBooks.erase(it);
        } else {
            cout << "This book was not borrowed by the member." << endl;
        }
    }

    void showBorrowedBooks() {
        cout << "Books borrowed by " << name << ":" << endl;
        for (auto& book : borrowedBooks) {
            cout << book->getTitle() << endl;
        }
    }
};

// Derived class: Staff
class Staff : public Person {
public:
    Staff(string name, int id) : Person(name, id) {}

    void login() override {
        cout << "Staff " << name << " logged in." << endl;
    }

    void logout() override {
        cout << "Staff " << name << " logged out." << endl;
    }

    void manageInventory() {
        cout << "Staff " << name << " is managing the inventory." << endl;
    }
};

// Class: Library
class Library {
private:
    vector<Book*> books;
    vector<Member*> members;
    vector<Staff*> staff;

public:
    ~Library() {
        // Clean up dynamically allocated memory
        for (auto book : books) delete book;
        for (auto member : members) delete member;
        for (auto staffMember : staff) delete staffMember;
    }

    void addBook(Book* book) {
        books.push_back(book);
    }

    void addMember(Member* member) {
        members.push_back(member);
    }

    void addStaff(Staff* staffMember) {
        staff.push_back(staffMember);
    }

    void showBooks() {
        cout << "Library Books:" << endl;
        for (auto book : books) {
            cout << book->getTitle() << " by " << book->getAuthor() << " (ISBN: " << book->getISBN() << ")" << endl;
        }
    }

    Member* findMember(int id) {
        for (auto member : members) {
            if (member->id == id) {
                return member;
            }
        }
        return nullptr;
    }

    Book* findBook(string isbn) {
        for (auto book : books) {
            if (book->getISBN() == isbn) {
                return book;
            }
        }
        return nullptr;
    }
};

int main() {
    // Create a library
    Library library;

    // Add books to the library
    library.addBook(new Book("The Great Gatsby", "F. Scott Fitzgerald", "123456789"));
    library.addBook(new Book("1984", "George Orwell", "987654321"));

    // Add members to the library
    library.addMember(new Member("Alice", 1));
    library.addMember(new Member("Bob", 2));

    // Add staff to the library
    library.addStaff(new Staff("Charlie", 101));

    // Display all books in the library
    library.showBooks();

    // Find a member and let them borrow a book
    Member* member = library.findMember(1);
    Book* book = library.findBook("123456789");

    if (member && book) {
        member->login();
        member->borrowBook(book);
        member->showBorrowedBooks();
        member->logout();
    }

    // Return the book
    if (member && book) {
        member->login();
        member->returnBook(book);
        member->showBorrowedBooks();
        member->logout();
    }

    return 0;
}
