#include<iostream>
using namespace std;

class Car{
	private:
		string brand;
		string model;
		int year;
	public:
		Car() : brand("unknown"), model("unknown"), year(0) {}
		
		Car(string b, string m, int y) : brand(b), model(m), year(y) {}
		
		void display() {
			cout<<"Car Details:"<<endl;
			cout<<"Brand: "<<brand<<endl;
			cout<<"Model: "<<model<<endl;
			cout<<"Year: "<<year<<endl;
		}
};

int main() {
	Car c;
	cout<<"Car 1:"<<endl;
	c.display();
	cout<<endl;
	
	Car c2("Jaguar", "FtypeR", 2023);
	cout<<"Car 2:"<<endl;
	c2.display();
}