#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include <memory>
#include <fstream>
#include <cstring>
#include <conio.h>
#include <Windows.h>
#include <ctime>
using namespace std;

// Player Class
class Player {
private:
    string name;
    string position;
    int goals;
    int assists;
    string teamAffiliation;

public:
    Player(string n, string p, string t) : name(n), position(p), goals(0), assists(0), teamAffiliation(t) {}

    void updateStats(int g, int a) {
        goals += g;
        assists += a;
    }

    void transferToTeam(string newTeam) {
        teamAffiliation = newTeam;
    }

    void displayInfo() const {
        cout << "Name: " << name << "\nPosition: " << position << "\nGoals: " << goals << "\nAssists: " << assists << "\nTeam: " << teamAffiliation << endl;
    }

    bool operator==(const Player& other) const {
        return name == other.name;
    }

    string getName() const {
        return name;
    }

    void setPosition(string newPosition) {
        position = newPosition;
    }
};

// Team Class
class Team {
private:
    string name;
    vector<Player> players;
    string coach;
    int wins;
    int losses;
    int draws;

public:
    Team(string n, string c) : name(n), coach(c), wins(0), losses(0), draws(0) {}

    void addPlayer(const Player& p) {
        players.push_back(p);
    }

    void removePlayer(const Player& p) {
        auto it = find(players.begin(), players.end(), p);
        if (it != players.end()) {
            players.erase(it);
        }
    }

   void updateTeamStats(int score1, int score2) {
    if (score1 > score2) {
        wins++;
    } else if (score1 < score2) {
        losses++;
    } else {
        draws++;
    }
}


    void displayTeamInfo() const {
        cout << "Team Name: " << name << "\nCoach: " << coach << "\nWins: " << wins << "\nLosses: " << losses << "\nDraws: " << draws << "\nPlayers:" << endl;
        for (const auto& player : players) {
            player.displayInfo();
            cout << "---" << endl;
        }
    }

    string getName() const {
        return name;
    }
};

// Match Class
class Match {
private:
    Team* team1;
    Team* team2;
    int team1Score;
    int team2Score;
    string date;
    string location;

public:
    Match(Team* t1, Team* t2, string d, string l) : team1(t1), team2(t2), date(d), location(l), team1Score(0), team2Score(0) {}

    void scheduleMatch() const {
        cout << "Match scheduled between " << team1->getName() << " and " << team2->getName() << " on " << date << " at " << location << "." << endl;
    }

    void updateScore(int t1Score, int t2Score) {
        team1Score = t1Score;
        team2Score = t2Score;
    }

    void displayMatchDetails() const {
        cout << "Match Details:\nTeam 1: " << team1->getName() << " - Score: " << team1Score << "\nTeam 2: " << team2->getName() << " - Score: " << team2Score << "\nDate: " << date << "\nLocation: " << location << endl;
    }
};

// Group Class
class Group {
private:
    string name;
    vector<Team*> teams;
    map<Team*, int> standings;

public:
    Group(string n) : name(n) {}

    void addTeam(Team* t) {
        teams.push_back(t);
        standings[t] = 0;
    }

    void removeTeam(Team* t) {
        auto it = find(teams.begin(), teams.end(), t);
        if (it != teams.end()) {
            teams.erase(it);
            standings.erase(t);
        }
    }

    void updateStandings(Team* t, int pts) {
        standings[t] += pts;
    }

    void displayGroupDetails() const {
        cout << "Group Name: " << name << "\nTeams:" << endl;
        for (const auto& team : teams) {
            cout << team->getName() << endl;
        }
        cout << "Standings:" << endl;
        for (const auto& entry : standings) {
            cout << entry.first->getName() << " - " << entry.second << " pts" << endl;
        }
    }

    const vector<Team*>& getTeams() const {
        return teams;
    }
};

// League Class (Base class for different leagues)
class League : public Group {
private:
    vector<unique_ptr<Match>> matches;

protected:
    void organizeMatches() {
        const auto& teams = getTeams();
        for (size_t i = 0; i < teams.size(); ++i) {
            for (size_t j = i + 1; j < teams.size(); ++j) {
                auto match = make_unique<Match>(teams[i], teams[j], "2023-05-01", "Old Trafford");
                match->scheduleMatch();
                match->updateScore(2, 1);  // Example score
                matches.push_back(move(match));
            }
        }
    }

public:
    League(string name) : Group(name) {}

    void updateLeagueTable() {
        for (const auto& match : matches) {
            match->displayMatchDetails();
        }
    }

    void simulateSeason() {
        for (int i = 0; i < 10; ++i) {
            organizeMatches();
            updateLeagueTable();
        }
    }
};

// ChampionLeague Class
class ChampionLeague : public League {
public:
    ChampionLeague() : League("Champions League") {}

    // Simulate a Champions League match
    void simulateChampionsLeagueMatch() {
        // Randomly select two teams for the match (assuming at least two teams exist)
        srand(time(nullptr));
        int team1Index = rand() % getTeams().size();
        int team2Index;
        do {
            team2Index = rand() % getTeams().size();
        } while (team2Index == team1Index);

        Team* team1 = getTeams()[team1Index];
        Team* team2 = getTeams()[team2Index];

        // Simulate match result (assuming random scores)
        int team1Score = rand() % 6;  // Random score between 0 and 5
        int team2Score = rand() % 6;  // Random score between 0 and 5

        // Update match scores
        team1->updateTeamStats(team1Score, team2Score);
        team2->updateTeamStats(team2Score, team1Score);

        // Display match details
        cout << "Champions League Match Details:\n";
        cout << "Team 1: " << team1->getName() << " - Score: " << team1Score << "\n";
        cout << "Team 2: " << team2->getName() << " - Score: " << team2Score << "\n";
    }
};

// PremierLeague Class
class PremierLeague : public League {
public:
    PremierLeague() : League("Premier League") {}

    // Simulate a Premier League match
    void simulatePremierLeagueMatch() {
        // Randomly select two teams for the match (assuming at least two teams exist)
        srand(time(nullptr));
        int team1Index = rand() % getTeams().size();
        int team2Index;
        do {
            team2Index = rand() % getTeams().size();
        } while (team2Index == team1Index);

        Team* team1 = getTeams()[team1Index];
        Team* team2 = getTeams()[team2Index];

        // Simulate match result (assuming random scores)
        int team1Score = rand() % 6;  // Random score between 0 and 5
        int team2Score = rand() % 6;  // Random score between 0 and 5

        // Update match scores
        team1->updateTeamStats(team1Score, team2Score);
        team2->updateTeamStats(team2Score, team1Score);

        // Display match details
        cout << "Premier League Match Details:\n";
        cout << "Team 1: " << team1->getName() << " - Score: " << team1Score << "\n";
        cout << "Team 2: " << team2->getName() << " - Score: " << team2Score << "\n";
    }
};

// PlayerManager Class
class PlayerManager {
private:
    vector<Player> players;

public:
    void addPlayer() {
        string name, position, teamAffiliation;
        cout << "Enter player name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter position: ";
        cin >> position;
        cout << "Enter team affiliation: ";
        cin >> teamAffiliation;
        players.push_back(Player(name, position, teamAffiliation));
        cout << "Player added successfully!" << endl;
    }

    void displayPlayers() {
        for (const auto& player : players) {
            player.displayInfo();
            cout << "---" << endl;
        }
    }

    void updatePlayer() {
        string name;
        cout << "Enter player name to update: ";
        cin.ignore();
        getline(cin, name);

        auto it = find_if(players.begin(), players.end(), [&name](const Player& p) { return p.getName() == name; });
        if (it != players.end()) {
            string newPosition, newTeamAffiliation;
            int goals, assists;
            cout << "Enter new position: ";
            cin >> newPosition;
            cout << "Enter new team affiliation: ";
            cin >> newTeamAffiliation;
            cout << "Enter goals: ";
            cin >> goals;
            cout << "Enter assists: ";
            cin >> assists;
            it->setPosition(newPosition);
            it->transferToTeam(newTeamAffiliation);
            it->updateStats(goals, assists);
            cout << "Player updated successfully!" << endl;
        } else {
            cout << "Player not found!" << endl;
        }
    }

    void deletePlayer() {
        string name;
        cout << "Enter player name to delete: ";
        cin.ignore();
        getline(cin, name);

        auto it = find_if(players.begin(), players.end(), [&name](const Player& p) { return p.getName() == name; });
        if (it != players.end()) {
            players.erase(it);
            cout << "Player deleted successfully!" << endl;
        } else {
            cout << "Player not found!" << endl;
        }
    }
};

void displayMenu() {
	
	cout<< "\t\t\t\t--------------Enter your choice-----------------\n";
    cout << "\t\t\t\t1. Add Player\n";
    cout << "\t\t\t\t2. Display Players\n";
    cout << "\t\t\t\t3. Update Player\n";
    cout << "\t\t\t\t4. Delete Player\n";
    cout << "\t\t\t\t5. Simulate Premier League Match\n";
    cout << "\t\t\t\t6. Simulate Champions League Match\n";
    cout << "\t\t\t\t7. Exit\n";
}

int main() {
	 
    // Login Credentials
    char uname[100] = "admin", password[100] = "12345";
    char u1[100], p1[100];

    cout << "--------------------------------------------------------------------------------------";
    cout << "\n\t\t\t<<  Kindly Add Your Credentials >>";
    cout << "\n\t\t\t\tEnter Username:";
    cin >> u1;

    cout << "\n\t\t\t\tEnter Password:";
    cin >> p1;

    // Check login credentials
    if (strcmp(uname, u1) == 0 && strcmp(password, p1) == 0) {
        cout << "\n\t\t\t\tWelcome! Login Successfully\n";
        system("COLOR A");

        // Create instances of Premier League and Champions League
        PremierLeague premierLeague;
        ChampionLeague championsLeague;

        // Player Manager
        PlayerManager playerManager;

        int choice;

        // Main menu loop
        do {
        	system("cls");
            displayMenu();
            cin >> choice;

            switch (choice) {
                case 1:
                    playerManager.addPlayer();
                    break;
                case 2:
                    playerManager.displayPlayers();
                    break;
                case 3:
                    playerManager.updatePlayer();
                    break;
                case 4:
                    playerManager.deletePlayer();
                    break;
                case 5:
                    premierLeague.simulateSeason();
                    break;
                case 6:
                    championsLeague.simulateSeason();
                    break;
                case 7:
                    char confirm;
                    cout << "Are you sure you want to exit? (y/n): ";
                    cin >> confirm;
                    if (confirm == 'y' || confirm == 'Y') {
                        cout << "Exiting..." << endl;
                        return 0;
                    } else {
                        cout << "Returning to main menu..." << endl;
                    }
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                    cin.clear(); // Clearing error flags
                    cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discarding invalid input
            }
        } while (true);
    } else {
        cout << "\n\t\t\t\tInvalid Credentials\n";
        system("COLOR 4");
    }

    return 0;
}

