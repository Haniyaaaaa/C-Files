#include<iostream>
using namespace std;

class Student{
	protected:
		string name;
		int rollNum;
	public:
		void getData(){
			cout<<"Enter name:"<<endl;
			cin>>name;
			cout<<"Enter roll num:"<<endl;
			cin>>rollNum;
		}
		void putData(){
			cout<<"Student Name:"<<name<<endl;
			cout<<"Roll Number:"<<rollNum<<endl;
		}
};

class Test : public Student {
	protected:
		int marks;
	public:
		void gettest(){
			cout<<"Enter marks obtained by "<<name<<":";
			cin>>marks;
		}
		void puttest() {
			cout<<"Marks obtained by "<< name <<":"<<marks<<endl;
		}
};

class Result : public Test {
	public:
		void displayResult() {
			cout<<"Total marks obtained by "<<name<<":"<<marks<<endl;
		}
};

int main() {
	Result r;
	
	cout<<"Enter student details:"<<endl;
	r.getData();
	cout<<"\nEnter test details:"<<endl;
	r.gettest();
	cout<<"\nStudent Information:"<<endl;
	r.putData();
	r.puttest();
    cout<<"\nResult:"<<endl;
    r.displayResult();
    
    return 0;
}