#include<iostream>
#include<fstream>
using namespace std;

class Sports{
	protected:
		string name;
		string typeofSport;
	public:
		Sports() {
			name="Sarah";
			typeofSport="Cricket";
		}
		Sports(string n, string ty) {
			name=n;
			typeofSport=ty;
		}
		string getName(){
			return name;
		}
		void setTypeOfSport(string ty){
				typeofSport=ty;
        }
		string getTypeOfSport(){
			return typeofSport;
		}
		void display(){
			cout<<"Type of Sports:"<<typeofSport<<endl;
		}
		void writeFile(ofstream& file){
			file << typeofSport <<"\n";
		}
};

class Cricket : public Sports{
	private:
		string batmanName;
		string bowlerName;
	public:
	Cricket(){
		batmanName="Babar Azam";
		bowlerName="Shadab khan";
	}	
	Cricket(string bn, string wn){
		batmanName=bn;
		bowlerName=wn;
	}
	void setBatmanName(string bn){
			batmanName=bn;
	}
	string getBatmanName(){
		return batmanName;
	}
	void setBowlerName(string wn){
		bowlerName=wn;
	}
	string getBowlerName(){
		return bowlerName;
	}
	void display() {
		Sports::display();
		cout<<"Cricket Player:"<<batmanName<<endl;
		cout<<"Bowler:"<<bowlerName<<endl;
	}
};

int main() {
	Cricket c;
	c.setBatmanName("Babar Azam");
	c.setBowlerName("Shadab Khan");
	
	c.setTypeOfSport("Cricket");
	
	ofstream file("Sports_type.txt");
	if(file.is_open()){
		c.writeFile(file);
		file.close();
		cout<<"Sport type is added"<<endl;
		}
		else {
			cout<<"Cannot add a type"<<endl;
		}
	
	ifstream readFile("Sports_type.txt");
	string data;
	while(getline(readFile, data)){
		cout<<data<<endl;
	}
	readFile.close();
	
	return 0;
}



