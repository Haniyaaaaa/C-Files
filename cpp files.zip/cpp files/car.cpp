#include <iostream>
#include <string>
using namespace std;

class Car {
private:
    int yearModel;
    string make;
    int speed;

public:
    // Constructor
    Car(int model, const string& carMake) {
        yearModel = model;
        make = carMake;
        speed = 0;
    }

    // Getters
    int getYearModel() const {
        return yearModel;
    }

    string getMake() const {
        return make;
    }

    int getSpeed() const {
        return speed;
    }

    // Setters
    void setYearModel(int model) {
        yearModel = model;
    }

    void setMake(const string& carMake) {
        make = carMake;
    }

    void setSpeed(int carSpeed) {
        speed = carSpeed;
    }

    // Accelerate function
    void accelerate() {
        speed += 10;
    }

    // Brake function
    void brake() {
        if (speed >= 10) {
            speed -= 10;
        }
        else {
            speed = 0;
        }
    }
};

int main() {
    Car car1(2021, "Jaguar");
    Car car2(2022, "G-Wagon");

    // Accelerating car1 five times
    cout << "Accelerating car1:" << endl;
    for (int i = 0; i < 5; i++) {
        car1.accelerate();
        cout << "Current speed after acceleration " << i + 1 << ": " << car1.getSpeed() << " mph" << endl;
    }
    cout << endl;

    // Braking car1 five times
    cout << "Braking car1:" << endl;
    for (int i = 0; i < 5; i++) {
        car1.brake();
        cout << "Current speed after braking " << i + 1 << ": " << car1.getSpeed() << " mph" << endl;
    }
    cout << endl;

    // Accelerating car2 three times
    cout << "Accelerating car2:" << endl;
    for (int i = 0; i < 3; i++) {
        car2.accelerate();
        cout << "Current speed after acceleration " << i + 1 << ": " << car2.getSpeed() << " mph" << endl;
    }
    cout << endl;

    // Braking car2 four times
    cout << "Braking car2:" << endl;
    for (int i = 0; i < 4; i++) {
        car2.brake();
        cout << "Current speed after braking " << i + 1 << ": " << car2.getSpeed() << " mph" << endl;
    }
    cout << endl;

    return 0;
}