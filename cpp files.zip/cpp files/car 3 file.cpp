#include<iostream>
#include<fstream>
using namespace std;

class Car{
	protected:
		string brand;
		string model;
		int year;
		double price;
	public:
		Car(string b, string m, int y, double p) : brand(b), model(m), year(y), price(p) {}
		
		string getBrand() {
			return brand;
		}
		string getModel() {
			return model;
		}
		int getYear() {
			return year;
		}
		double getPrice() {
			return price;
		}
		
	void writeFile(ofstream& file){
		file << brand <<"\n";
	}
	
	void display() {
		cout<<"Brand:"<<brand<<endl;
		cout<<"Model:"<<model<<endl;
		cout<<"Year:"<<year<<endl;
		cout<<"Price: $"<<price<<endl;
	}
};

 void displayInfo(Car* car) {
 	car->display();
 }
 
 int main() {
        Car c("Jaguar", "Ftyper", 2022, 2000000.0);
        
    ofstream file("Car_brand.txt");
 	if(file.is_open()){
 	    c.writeFile(file);
		file.close();
 		cout<<"Brand added successfully"<<endl;
	 }
	 else {
	 	cout<<"Cant add brand"<<endl;
	 }
        
        ifstream readfile("Car.txt");
        string record;
        while(getline(readfile, record)){
        	cout<<record<<endl;
		}
        readfile.close();
        
        return 0;
 }
 
 
 
 
 