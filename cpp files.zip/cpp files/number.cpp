#include<iostream>
#include<cmath>
using namespace std;

class Number{
	protected:
		double num;
	public:
		Number(double n) : num(n) {}
		
		virtual void wholeNum() {
			if(num == floor(num)) {
				cout<<num<<"is whole number"<<endl;
			}
			else {
				cout<<num<<"is not a whole number"<<endl;
			}
		}
		virtual void checkPositive() {
			if(num>0) {
				cout<<num<<"is a positive number"<<endl;
			}
			else {
				cout<<num<<"is not a positive number"<<endl;
			}
		}
		virtual void calFac() {
			cout<<"Factorial of"<<num<<"is not defined for general number"<<endl;
		}
};

class IntegerNum : public Number {
	public:
		IntegerNum(int n) : Number(n) {}
		
		void wholeNum() override {
			if (num == floor(num)) {
				cout<<num<<"is an integer"<<endl;
			}
			else {
				cout<<num<<"is not an integer"<<endl;
			}
		}
		void calFac() {
			int fact=1;
			for(int i=1; i <= num; ++i) {
				fact *= 1;
			}
			cout<<"Factorial of"<<num<<"is:"<<fact<<endl;
		}
};

class FloatNum : public Number {
	public:
		FloatNum(int n) : Number(n) {} 
		
		void wholeNum() override {
			cout<<num<<"is a float number"<<endl;
		}
		void checkPositive() override {
			if(num > 0) {
				cout<<num<<"is a positive number"<<endl;
			}
			else if (num < 0) {
				cout<<num<<"is not a negative number"<<endl;
			}
			else {
				cout<<num<<"is zero"<<endl;
			}
		}
		void calFac() override {
			cout<<"Factorial of a float number is not defined"<<endl;
		}
};

int main () {
	Number* num1 = new IntegerNum(4);
	Number* num2 = new FloatNum(-6.7);
	
	num1->wholeNum();
	num1->checkPositive();
	num1->calFac();
	
	cout<<"\n";
	num2->wholeNum();
	num2->checkPositive();
	num2->calFac();
	
	delete num1;
	delete num2;
	return 0;
}
