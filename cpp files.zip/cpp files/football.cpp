#include<iostream>
#include<fstream>
#include<string>
#include<conio.h>
#include<Windows.h>

using namespace std;

class PLayer{
	private:
//these are the terms used in football
		string name, ID, numofCatches, numOfTouchDowns, receivingYards, rushingYards, position, passingYards;
	public:
		void menu();
		void getdata();
		void display();
		void update();
		void search();
		void deleteData();
		void deleteAll();
};
//method to define function of class

void player::menu() {
	
label:
	int choice;
	char x;
	system("cls");
	system("COLOR A");
	cout<<"\t\t\t-----------------------------"<<endl;
	cout<<"\t\t\t|  CLUB MANAGEMENT SYSTEM   |"<<endl;
	cout<<"\t\t\t-----------------------------"<<endl;
	cout<<"\t\t\t 1. Enter New Record"<<endl;
	cout<<"\t\t\t 2. Sisplay Record"<<endl;
	cout<<"\t\t\t 3. Update Record"<<endl;
	cout<<"\t\t\t 4. Search Record"<<endl;
	cout<<"\t\t\t 5. Delete Record"<<endl;
	cout<<"\t\t\t 6. Delete All"<<endl;
	cout<<"\t\t\t 7. Exit"<<endl;
	cout<<"Ente Your Choice:";
	cin>>choice;
	
	switch(choice){
		case 1:
			system("COLOR B")
			do {
				getdata();
				cout<<"\n\t\t\t Do you want to Add Another Player Data [y/n]:";
				cin>>x;
			} while (x== 'y' || x=='Y');
		    break;
		case 2:
			system("COLOR B");
			display();
			break;
		case 3:
			system("COLOR E");
			update();
			break;
		case 4:
		    system("COLOR E");
			search();
			break;
		case 5:
		    system("COLOR D");
		//used to delete data of one player
		    deleteData();
		    break;
		case 6:
		    system("COLOR C");
		//used to delete the data of all player
		    deleteAll();
		    break;
		case 7:
		//exit from program
			exit(0);
			break;
		default:
			cout<<"\n\t\t\t Invalid choice... Please Try Again"<<endl;	
	}
	_getch();
	//label work as a loop when the action is performed
	goto label;	
}
void player::getdata() {
	system("cls");
	//for file handling
	ofstream write;
	cout<<"\n-------------------------------------------------------------------------------------";
	cout<<"\n-------------------------------Add Players Details-------------------------";
     
    cout<<" Enter player name:";
    cin,ignore();
    getline(cin,name); //player name
    cout<<"Enter Player ID:"; //player id
    cin>>ID;
    cout<<"Enter the position:"; ///position of player
    cin>>position;
    cout<<"Enter the number of touch downs:"; //no of touch downs
    cin>>numOfTouchDowns;
    cout<<"Enter the number of catches:"; //no of catch
    cin>>numofCatches;
    cout<<"Enter the number of apssing yards:";
    cin>>passingYards;
    cout<<"Enter the number of recieving yards";
    cin>>receivingYards;
    cout<<"Enter the number of rushing yards";
    cin>>rushingYards;
// to save data into file 
    write.open("PlayerRecord.txt", ios::app | ios::out);
    
    write<< name <<" ";
    write<< ID <<" ";
    write<< position <<" ";
    write<< numOfTouchDowns <<" ";
    write<< numofCatches <<" ";
    write<< passingYards <<" ";
    write<< receivingYards <<" ";
    write<< rushingYards <<" "<<"\n";

    write.close();
}
void player::display() {
	  system("cls");
	  fstream file;  //to read data from file
	  int total = 1;
	  cout<<"\n------------------------------------------------------------------------------";
	  cout<<"--------------------------------Player Data Table---------------------------";
	  file.open("PlayerRecord.txt", ios::in);
	  if(!file) {
	  	cour<<"\n\t\t\No Data Is Present...";
	  	file.close();
	  }
	  else {
	  	file>>name;
	  	file>>ID;
	  	file>>position;
	  	file>>numOfTouchDowns;
	  	file>>numofCatches;
	  	file>>passingYards;
	  	file>>receivingYards;
	  	file>>rushingYards;
	  	//eof mean end of file it is built-in function
	  	while(!file.eof()) {
	  		cout<<"\n\n\t\t\t Player Name:"<<name;
	  		cout<<"\n\t\t\t Player ID:"<<ID;
	  		cout<<"\n\t\t\t Position:"<<position;
	  		cout<<"\n\t\t\t Number of Touch Downs:"<<numOfTouchDowns;
	  		cout<<"\n\t\t\t Number of Catches:"<<numofCatches;
	  		cout<<"\n\t\t\t Number of Passing Yards:"<<passingYards;
	  		cout<<"\n\t\t\t Number of Receving Yards:"<<receivingYards;
	  		cout<<"\n\t\t\t Number of Rushing Yards:"<<rushingYards;
	  		//to read the data from file
	  		file>>name;
	  		file>>ID;
	  		file>>position;
	  		file>>numOfTouchDowns;
	  		file>>numofCatches;
	  		file>>passingYards;
	  		file>>receivingYards;
	  		file>>rushingYards;
		  }	
		if(total == 0) {
			cout<<"\n\t\t\tNo Data Is Present...";
		}
	  }
	   file.close();
}
void player::update() {
	   system("cls");
	   fstream file, file1;
	   string eyeD;
	   int found = 0;
	   cout<<"-----------------------------------------------------------------------------------------------------";
	   cout<<"-------------------------------------- Update Player Data--------------------------------------------";
	   file.open("PlayerRecord.txt". ios::in);
	   if (!file){
	   	cout<<"\n\t\t\tNo Data Is Present..";
	   }
	   else {
	   	cout<<"\nEnter Player ID to Update:";
	   	cin>>eyeD;
	   	file1.open("Temp.txt", ios::app | ios::out);
	//we saved first our data in temporary file
	//and delete original file
	//then paster temporary file into original
	   	file>>name;
	  	file>>ID;
	  	file>>position;
	  	file>>numOfTouchDowns;
	  	file>>numofCatches;
	  	file>>passingYards;
	  	file>>receivingYards;
	  	file>>rushingYards;
	  	
	  	while (!file.eof()) {
	  		if (eyeD != ID) {
	  		
	  		file1<<name<<" ";
	  		file1<<ID<<" ";
	  		file1<<position<<" ";
	  		file1<<numOfTouchDowns<<" ";
	  		file1<<numofCatches<<" ";
	  		file1<<passingYards<<" ";
	  		file1<<receivingYards<<" ";
	  		file1<<rushing Yards<<" ";
		  }
		  
		  else {
		  	cout<<"Enter player name:";
		  	cin.ignore();
		  	getline(cin,name);
		  	cout<<"Enter player ID:";
		  	cin>>ID;
		  	cout<<"Enter the position:";
		  	cin>>position;
		  	cout<<"Enter the number of touch downs:"; //no of touch downs
            cin>>numOfTouchDowns;
            cout<<"Enter the number of catches:"; //no of catch
            cin>>numofCatches;
            cout<<"Enter the number of apssing yards:";
            cin>>passingYards;
            cout<<"Enter the number of recieving yards";
            cin>>receivingYards;
            cout<<"Enter the number of rushing yards";
            cin>>rushingYards;
            
        	file1<<name<<" ";
	  		file1<<ID<<" ";
	  		file1<<position<<" ";
	  		file1<<numOfTouchDowns<<" ";
	  		file1<<numofCatches<<" ";
	  		file1<<passingYards<<" ";
	  		file1<<receivingYards<<" ";
	  		file1<<rushing Yards<<" "<<"\n"; 
	  		found++;
		  }
		  
		file>>name;
	  	file>>ID;
	  	file>>position;
	  	file>>numOfTouchDowns;
	  	file>>numofCatches;
	  	file>>passingYards;
	  	file>>receivingYards;
	  	file>>rushingYards;
	  	cout<<"\n\t\t\tData Updates Successfully";
	  	if(found == 0) {
	  		cout<<"\n\n\t\t\t Player ID not Found....";
		  }
	   }
	file1.close();
	file.close();
	remove("PlayerRecord.txt");
//remove and rename are built-in function in iostream lab
	rename("Temp.txt", "PlayerRecord.txt");
	
void player::search(){
	system("cls");
	fstream file;
	int found = 0;
	file.open("PlayerRecord.txt", ios::in);
	if (!file) {
		cout<<"\n-------------------------------------------------------------------------------------------------";
		cout<<"----------------------------------------Search Player Data-----------------------------------------";
		cout<<"\n\t\t\t No Data Is Present...";
	}
	else {
		string eyeD;
		cout<<"\n--------------------------------------------------------------------------------------------------";
		cout<<"----------------------------------------Search Player Data------------------------------------------";
		cout<<"\n Enter Player ID to search:";
		cin>>eyeD;
		//file handling
		file>>name;
	  	file>>ID;
	  	file>>position;
	  	file>>numOfTouchDowns;
	  	file>>numofCatches;
	  	file>>passingYards;
	  	file>>receivingYards;
	  	file>>rushingYards;
	  	
	  	while (!file.eof()) {
	  		if(eyeD == ID) {
	  		cout<<"\n\n\t\t\t Player Name:"<<name;
	  		cout<<"\n\t\t\t Player ID:"<<ID;
	  		cout<<"\n\t\t\t Position:"<<position;
	  		cout<<"\n\t\t\t Number of Touch Downs:"<<numOfTouchDowns;
	  		cout<<"\n\t\t\t Number of Catches:"<<numofCatches;
	  		cout<<"\n\t\t\t Number of Passing Yards:"<<passingYards;
	  		cout<<"\n\t\t\t Number of Receving Yards:"<<receivingYards;
	  		cout<<"\n\t\t\t Number of Rushing Yards:"<<rushingYards;
	  		found++;
			  }
		file>>name;
	  	file>>ID;
	  	file>>position;
	  	file>>numOfTouchDowns;
	  	file>>numofCatches;
	  	file>>passingYards;
	  	file>>receivingYards;
	  	file>>rushingYards;
		  }
		 if (found == 0) {
		 	cout<<"\n\t\t\tPlayer ID Not Found...";
		 }
		 file.close();
	}
}

void player::deleteData() {
	system("cls");
	fstream file, file1;
	int found = 0;
	string id;
	cout<<"\n---------------------------------------------------------------------------------------------------";
	cout<<"-------------------------------------------Delete Player Data----------------------------------------";
	file.open("PlayerRecord.txt", ios::in);
	if (!file) {
		cout<<"\n\t\t\tNo Data is Present..";
		file.close();
	}
	else {
		cout<<"\nEnter Player ID to Delete:";
		cin>>id;
		file1.open("Temp.txt", ios::app | ios::out);
		
		file>>name;
	  	file>>ID;
	  	file>>position;
	  	file>>numOfTouchDowns;
	  	file>>numofCatches;
	  	file>>passingYards;
	  	file>>receivingYards;
	  	file>>rushingYards;
	  	
	  	while (!file.eof()) {
	  		if (id !=ID) {
	  		file1<<name<<" ";
	  		file1<<ID<<" ";
	  		file1<<position<<" ";
	  		file1<<numOfTouchDowns<<" ";
	  		file1<<numofCatches<<" ";
	  		file1<<passingYards<<" ";
	  		file1<<receivingYards<<" ";
	  		file1<<rushing Yards<<" "<<"\n"; 
			  }
			else {
				found++;
				cout<<"\n\t\t\tData Delete Successfully";
			}
		file>>name;
	  	file>>ID;
	  	file>>position;
	  	file>>numOfTouchDowns;
	  	file>>numofCatches;
	  	file>>passingYards;
	  	file>>receivingYards;
	  	file>>rushingYards;
	 }
		  if (found == 0) {
		  	cout<<"\n\t\t\tPlayer ID Not Found...";
		  }
		  file1.close();
		  file.close();
		  remove("PlayerRecord.txt");
		  rename("Temp.txt", "PlayerRecord.txt");
	}
}

void player::deleteAll() {
	system("cls");
	int x;
	cout<<"Are you sure you want to delete all of player...?\n Press 1 to confirm:";
	cin>>x;
	
	if (x == 1) {
		remove("PlayerRecord.txt";
		ofstream writeFile("PlayerRecord.txt");
		writeFile.close;
	}
}

void welcome() {
	system("COLOR E");
	ifstream read;
	read.open("welcome.txt", ios::in);
	if (!read) {
		cout<<"No such File";
	}
	else {
		string text;
		while (getline(read, text, '\n')) {
		//output the text from the file
		cout<<end<<text;
		}
	}
	read.close(); 
	
	cout<<"\n\n\t\t\t\tPress any key to continue...";
	_getch();
	//code after sleep of after character
}
	int main() {
		system("COLOR 5");
	    //login management
	char uname[100] = "admin", password[100] = "5121472";
	char u1[100], p1[100];
	cout<<"\n\t\t\t\tEnter Username:";
	con>>u1;
	cout<<"\n\t\t\ttEnter Password:";
	cin>>p1;
	//strcmp is user defined function in iostream lab
	if (strcmp(uname, u1) == 0, strcmp (password, p1) == 0) {
		cout<<"\n\t\t\t\tWelcome! Login Successfulyy\n";
	}
	else {
		cout<<"\n\t\t\t\tWrong username or password :( \n";
		exit(0);
		
		welcome();
		player project;
		project.menu();
		return 0;
}
