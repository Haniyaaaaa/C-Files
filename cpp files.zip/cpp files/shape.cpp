#include<iostream>
#include<fstream>
#include<cmath>
using namespace std;

class Shape {
public:
    virtual double calArea() {
        cout << "Calculating area of a 2D shape" << endl;
        return 0.0;
    }
    
    double calArea(double h, double w) {
        cout << "Calculating area of a rectangle" << endl;
        return h * w;
    }
    
    double calArea(double radius) {
        cout << "Calculating area of a circle" << endl;
        return 3.14 * pow(radius, 2);
    }
    
    virtual double calPerimeter() {
        cout << "Calculating perimeter of 2D shape" << endl;
        return 0.0;
    }
    
    virtual double getSideLength() = 0;
    
    void displayInfo() {
        cout << "Shape Info:" << endl;
        cout << "Area: " << calArea() << endl;
        cout << "Perimeter: " << calPerimeter() << endl;
    }
    
    void ShapeFile(string filename) {
        ofstream file(filename);
        if (file.is_open()) {
            file << "Shape Info:" << endl;
            file << "Area: " << calArea() << endl;
            file << "Perimeter: " << calPerimeter() << endl;
            file.close();
            cout << "Shape Info is saved in: " << filename << endl;
        }
        else {
            cout << "Can't open file" << endl;
        }
    }
    
    void LoadShapeFile(string filename) {
        ifstream file(filename);
        if (file.is_open()) {
            string line;
            while (getline(file, line)) {
                cout << line << endl;
            }
            file.close();
        }
        else {
            cout << "Can't open file" << endl;
        }
    }
    
    //static Shape* createShape() {
    //  return new Shape();
    //}
    
    //static void deleteShape(Shape* shape) {
    //   delete shape;
    //    cout << "Shape deleted" << endl;
   // }
   
   virtual ~Shape() {}
};

class Rectangle : public Shape {
private:
    double height;
    double width;
public:
    Rectangle(double h, double w) : height(h), width(w) {}
    
    double calArea() override {
        cout << "Calculating area of rectangle" << endl;
        return height * width;
    }
    
    double calPerimeter() override {
        cout << "Calculating perimeter of rectangle" << endl;
        return 2 * (height + width);
    }
    
    double getSideLength() override {
        cout << "Get side length of rectangle" << endl;
        return width;
    }
};

class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}
    
    double calArea() override {
        cout << "Calculating area of circle" << endl;
        return 3.14 * pow(radius, 2);
    }
    
    double calPerimeter() override {
        cout << "Calculating perimeter of circle" << endl;
        return 2 * 3.14 * radius;
    }
    
    double getSideLength() override {
        cout << "Get side length of circle" << endl;
        return 0.0;
    }
};

int main() {
    Shape* shape = new Rectangle(5.0, 10.0);
    shape->displayInfo();
    shape->ShapeFile("rectangle_info.txt");
    shape->LoadShapeFile("rectangle_info.txt");
    delete shape;
    
    shape = new Circle(3.5);
    shape->displayInfo();
    shape->ShapeFile("circle_info.txt");
    shape->LoadShapeFile("circle_info.txt");
    delete shape;
    
    return 0;
}