#include<iostream>
using namespace std;

class Triangle{
	public:
		static bool Triangle_test(double side1, double side2, double side3) {
			return (side1 < side2 + side3) && (side2 < side1 + side3) && (side3 < side1 + side2);
		}
};
int main () {
	double side1, side2, side3;
	cout<<"Enter the three side of triangle:"<<endl;
	cin>>side1>>side2>>side3;
	
	if (Triangle::Triangle_test(side1, side2, side3)){
		cout<<"these sides can form a triangle"<<endl;
	} else {
		cout<<"these triangle cannot form a triangle"<<endl;
	}
	return 0;
}