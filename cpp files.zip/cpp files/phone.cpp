#include<iostream>
using namespace std;

class Phone {
	private:
		string color;
		string model;
	public:
		Phone(){
			color=c;
			model=m;
		}
	void setColor(string c){
		color=c;
	}
	string getColor(){
		return color;
	}
	void setModel(string m){
		model=m;
	}
	string getModel(){
		return model;
	}
	~Phone(){
		cout<<"Iphone"<<endl;
	}
	void displayInfo(){
		cout<<"Color:"<<color<<endl;
		cout<<"Model:"<<model<<endl;
	}
};

int main{
     Phone p
     p.setColor("red");
	 p.setModel("Iphone");
     cout<<void displayInfo();
}