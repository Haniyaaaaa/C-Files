#include<iostream>
using namespace std;

class Vehicle {
	protected:
		string manufacturer;
		int year;
	public:
		Vehicle(string manu, int y) : manufacturer(manu), year(y) {}
		
		virtual void display() {
			cout<<"Manufacturer: "<<manufacturer<<endl;
			cout<<"Year: "<<year<<endl;
		}
};

class Car : public Vehicle {
	private:
		string model;
		double price;
	public:
		Car(string manu, int y, string m,double p) : Vehicle(manu, y), model(m), price(p) {}
		
	void display() override {
		Vehicle::display();
		cout<<"Model: "<<model<<endl;
		cout<<"Price: "<<price<<endl;
	}
};

class Bicycle : public Vehicle {
	private:
		string type;
		int gear;
	public:
		Bicycle(string manu, int y, string t, int g) : Vehicle(manu, y), type(t), gear(g) {}
		
	void display() override {
		Vehicle::display();
		cout<<"Type: "<<type<<endl;
		cout<<"Gear: "<<gear<<endl;
	}
};

int main() {
	const int size = 2;
	Vehicle* vehicles[size];
	
	for(int i=0; i<size; i++){
		char choice;
		cout<<"Choose Vehicle Type - Enter C for car and B for Bicycle ";
		cin>>choice;
		if(choice == 'C'){
			string manufacturer, model;
			int year, gear;
			double price;
			
			cout<<"Enter Car Manufacturer: ";
			cin>>manufacturer;
			cout<<"Enter Car Model: ";
			cin>>model;
			cout<<"Enter Car Year: ";
			cin>>year;
			cout<<"Enter Price: ";
			cin>>price;
			
			vehicles[i] = new Car(manufacturer, year, model, price);
		} 
		else if (choice == 'B') {
			string manufacturer, type;
			int year, gear;
			
			cout<<"Enter Bicycle Manufacturer: ";
			cin>>manufacturer;
			cout<<"Enter Bicycle type: ";
			cin>>type;
			cout<<"Enter Bicycle year: ";
			cin>>year;
			cout<<"Enter Bicycle Gear: ";
			cin>>gear;
			
			vehicles[i] = new Bicycle(manufacturer, year, type, gear);
		}
	}
	cout<<"\nVehicles Details:\n";
	for(int i=0; i<size; i++){
		vehicles[i]->display();
		cout<<endl;
	}
	for(int i=0; i<size; i++){
		delete vehicles[i];
	}
	return 0;
}