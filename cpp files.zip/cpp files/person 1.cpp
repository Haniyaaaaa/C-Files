#include<iostream>
using namespace std;

class Person{
	private:
		string name;
		int age;
	public:
		Person(string n, int a) : name(n), age(a) {}
		
		void compareAge(const Person& other) {
			if(this->age < other.age){
				cout<<this->name<<" is younger than "<<other.name<<endl;
			}
			else if(this->age > other.age) {
				cout<<this->name<<" is older than "<<other.name<<endl;
			}
			else {
				cout<<this->name<<"and"<<other.name<<"are the same age"<<endl;
			}
		}
};

int main() {
	Person p1("Aneesa", 19);
	Person p2("Haniya", 20);
	
	p1.compareAge(p2);
	return 0;
}