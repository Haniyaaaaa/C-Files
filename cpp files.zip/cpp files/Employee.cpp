#include<iostream>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    double salary;

public:
    Employee(string n, int i, double s) : name(n), id(i), salary(s) {}

    string getName() {
        return name;
    }

    int getId() {
        return id;
    }

    double getSalary() {
        return salary;
    }

    void display() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Salary: " << salary << endl;
    }
};

class Manager : public Employee {
private:
    string department;
    int teamSize;

public:
    Manager(string dept, int ts, int i, double s, string n) : Employee(n, i, s), department(dept), teamSize(ts) {}

    string getDepartment() {
        return department;
    }

    int getTeamSize() {
        return teamSize;
    }

    void info() {
        cout << "Department Name: " << department << endl;
        cout << "Team Size: " << teamSize << endl;
    }
};

class Developer : public Manager {
private:
    string programmingLanguage;

public:
    Developer(string lang, int ts, int i, string dept, double s, string n) : Manager(dept, ts, i, s, n), programmingLanguage(lang) {}

    string getProgrammingLanguage() {
        return programmingLanguage;
    }

    void displayInformation() {
        cout << "Programming Language: " << programmingLanguage << endl;
        display();
        info(); 
    }
};

int main() {
    Developer developer("Python", 5, 56234, "CyberSecurity", 50000.0, "Yahya");
    developer.displayInformation();

    return 0;
}