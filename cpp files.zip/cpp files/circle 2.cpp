#include <iostream>
using namespace std;

class Circle {
private:
    double radius;
    static const double pi;

public:
    Circle(double r) : radius(r) {}

    static double getPi() {
        return pi;
    }

    double calculateArea() const {
        return pi * radius * radius;
    }

    double calculateCircumference() const {
        return 2 * pi * radius;
    }
};

const double Circle::pi = 3.14;

int main() {
    Circle circle1(5.0);
    Circle circle2(3.5);

    cout << "Value of PI: " << Circle::getPi() << endl;

    cout << "Circle 1 - Radius: 5.0\n";
    cout << "Area: " << circle1.calculateArea() << endl;
    cout << "Circumference: " << circle1.calculateCircumference() << endl;

    cout << "\nCircle 2 - Radius: 3.5\n";
    cout << "Area: " << circle2.calculateArea() << endl;
    cout << "Circumference: " << circle2.calculateCircumference() << endl;

    return 0;
}