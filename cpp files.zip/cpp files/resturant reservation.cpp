 #include<iostream>
using namespace std;

class Reservation {
	protected:
	    int reservationID;
	    string customerName;
	    string dateAndtime;
	    int tableNum;
	    int guestNum;
	public:
		Reservation(int id, string n, string t, int tab, int g) : reservationID(id), customerName(n), dateAndtime(t), tableNum(tab), guestNum(g) {}
		
		void displayReservation() {
			cout<<"Reservation ID:"<< reservationID << endl;
			cout<<"Customer Name:" <<customerName << endl;
			cout<<"Date And Time:" <<dateAndtime<< endl;
			cout<<"Table Number:" <<tableNum << endl;
			cout<<"Guest Number:" <<guestNum << endl;
		}
};

int main() {
	Reservation r1(1, "Anna", "2023-06-25 8:30", 4, 2);
	Reservation r2(2, "Sam", "2023-05-14 9:30", 3, 2);
	
	cout<<"Reservation 1 Details:"<<endl;
	r1.displayReservation();
	cout << endl;
	
	cout<<"Reservation 2 Details:"<<endl;
	r2.displayReservation();
	cout << endl;
	
	return 0;
}