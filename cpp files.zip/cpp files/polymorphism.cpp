#include<iostream>
#include<fstream>
using namespace std;

class bankAccount{
	protected:
		double balance;
	public:
		bankAccount(double bal) : balance(bal) {}
		
		double getBalance(){
			return balance;
		}
		//operator overloading
		bankAccount operator+(const bankAccount& obj) {
			double sum = balance + obj.balance;
			return bankAccount(sum);
		}
		
		//friend func
		friend void printBalance(const bankAccount& acc){
			cout<<"Balance:" << acc.balance <<endl;
		}
		
		//virtual void deposit(double amount) = 0;
		//virtual void withdraw(double amount) = 0;
		//virtual void calInterest() = 0;
		//virtual void displayInfo() = 0;	
		
		void writeFile(ofstream& file){
			file<< balance << "\n";
		}			
};

class savingAccount : public bankAccount {
	public:
		savingAccount(double bal) : bankAccount (bal) {}
		
	virtual	void deposit(double amount){
		balance += amount;
	}
	void deposit(double amount, int count){
		balance += amount * count;
	}
		
	virtual void withdraw(double amount){
		if(amount <= balance)
		balance -= amount;
	}
	
	virtual void calInterest() {
		double rate = 0.1;
		double interest= balance * rate;
		balance +=interest;
	}
	virtual void displayInfo() {
        cout << "Savings Account\n";
        cout << "Balance: " << balance << endl;
    }
};

class checkingAccount : public bankAccount {
public:
    checkingAccount(double Bal) : bankAccount(Bal) {}
    
    void deposit(double amount) {
        balance += amount;
    }

     void withdraw(double amount) {
        if (amount <= balance)
            balance -= amount;
    }

    void withdraw(double amount, double overlimit) {
        if (amount <= balance + overlimit)
            balance -= amount;
    }
    
     void calInterest() {
		double rate = 0.5;
		double interest = balance * rate;
		balance += interest;
   }
	 void displayInfo() {
		cout<<"Checking Accounts\n";
		cout<<"Balance:" << balance <<endl;
	}
};

void transferFunds(checkingAccount& acc1, savingAccount& acc2, double amount){
	if (amount <= acc1.getBalance()) {
	    acc1.withdraw(amount);
		acc2.deposit(amount);
	}
}	
	int main() {
		savingAccount saving(10000000.0);
		checkingAccount checking(40000.0);
		
		ofstream file("account_balance.txt");
		if(file.is_open()){
			saving.writeFile(file);
			checking.writeFile(file);
			file.close();
			cout<<"Account balance added to file successfully"<<endl;
			}
		else {
			cout<<"Filed to open file"<<endl;
		}
		
		saving.displayInfo();
		checking.displayInfo();
		
		saving.deposit(1000000);
		saving.displayInfo();
		
		checking.withdraw(500000);
		checking.displayInfo();
		
	    transferFunds(checking, saving, 15000);
	    saving.displayInfo();
	    checking.displayInfo();
	    
	    bankAccount combined = saving + checking;
	    printBalance(combined);
	    
	return 0;
}