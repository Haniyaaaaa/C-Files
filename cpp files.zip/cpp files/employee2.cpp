#include<iostream>
using namespace std;

class Employee {
protected:
    string name;
    string position;
public:
    Employee(string n, string p) : name(n), position(p) {}
    
    void displayInfo() {
        cout << "Name: " << name << endl;
        cout << "Position: " << position << endl;
    }
    
    virtual ~Employee() {
        cout << "Employee destructor called" << endl;
    }
    
    Employee(const Employee& other) : name(other.name), position(other.position){
        cout << "Employee copy constructor called" << endl;
    }
    
    class Manager : public Employee {
    protected:
        string dept;
        int yearOfService;
    public:
        Manager(string n, string p, string d, int y) : Employee(n, p), dept(d), yearOfService(y) {}
        
        void displayInfo() override {
            Employee::displayInfo();
            cout << "Department: " << dept << endl;
            cout << "Years of Service: " << yearOfService << endl;
        }   
        
        ~Manager(){
            cout << "Manager destructor called" << endl;
        }
        
        Manager(const Manager& other) : Employee(other), dept(other.dept), yearOfService(other.yearOfService){
            cout << "Manager copy constructor called" << endl;
        }
    };
    
    class SeniorManager : public Manager {
    private:
        int teamSize;
        double bonusPercentage;
    public:
        SeniorManager(string n, string p, string d, int y, int ts, double bp) : Manager(n, p, d, y), teamSize(ts), bonusPercentage(bp) {}
        
        void displayInfo() override {
            Manager::displayInfo();
            cout << "Team Size: " << teamSize << endl;
            cout << "Bonus Percentage: " << bonusPercentage << endl;   
        }
    };

};

int main() {
    Employee::SeniorManager sm("Junaid Khan", "Senior Manager", "Sales", 5, 10, 5.0);
    sm.displayInfo();
    return 0;
}